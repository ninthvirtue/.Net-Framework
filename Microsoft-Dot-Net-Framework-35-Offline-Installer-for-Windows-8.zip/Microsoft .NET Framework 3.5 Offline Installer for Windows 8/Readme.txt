Product:         Microsoft .NET Framework Offline Installer for Windows 8
Version:         2.0.0.0
Requirements:    Windows 8
Author:          J.C.P Laboratory (Cedric Poottaren)
Publisher:       AskVG.com


Description:
A tool that allows you to install Microsoft .NET Framework 3.5 Offline in Windows 8.


More Info:
http://www.askvg.com/download-microsoft-net-framework-3-5-offline-installer-for-windows-8/


Lisence:
This application is freeware and can only be distribured as is. If you paid for this app, ask for a refund.


Don't forget to visit AskVG.com.


Copyright � 2013 J.C.P Laboratory Software. All rights reserved.

http://www.AskVG.com/